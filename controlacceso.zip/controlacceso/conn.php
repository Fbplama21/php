<?php
	$conn=mysqli_connect("localhost", "root", "", "matriz");
	
	if(!$conn){
		die("Error: Failed to connect to database!");
	}
?>